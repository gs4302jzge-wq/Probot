const fs = require('fs');
const path = require('path');

// التقاط المسار الصحيح للملف
const configPath = path.join(__dirname, '../config/aliases.json');
const dataPath = path.join(__dirname, '../data/aliases.json');

function getAliases(guildId) {
    let aliases = {};
    try {
        if (fs.existsSync(dataPath)) {
            aliases = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        } else if (fs.existsSync(configPath)) {
            aliases = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        }
    } catch (e) {
        console.error('Error reading aliases:', e);
    }
    return aliases[guildId] || aliases || {};
}

function resolveMessageCommand(client, message) {
    if (!message || !message.guild || !message.content || message.author.bot) return null;

    const guildAliases = getAliases(message.guild.id);
    const args = message.content.trim().split(/ +/);
    const input = args.shift().toLowerCase();

    // البحث عن الأمر المطابق للاختصار
    let targetCommand = null;
    for (const [commandName, aliasList] of Object.entries(guildAliases)) {
        if (Array.isArray(aliasList) && aliasList.includes(input)) {
            targetCommand = commandName;
            break;
        } else if (typeof aliasList === 'string' && aliasList === input) {
            targetCommand = commandName;
            break;
        }
    }

    if (!targetCommand) return null;

    const command = client.commands.get(targetCommand);
    if (!command) return null;

    return {
        command,
        commandName: targetCommand,
        args,
        guildId: message.guild.id,
        aliasTriggered: true
    };
}

module.exports = { resolveMessageCommand };
